These files are from the [@NordicSemiconductor](https://github.com/NordicSemiconductor)[ble-sdk-arduino](https://github.com/NordicSemiconductor/ble-sdk-arduino).

Some file have been slightly modified.

extra files added by Low Power nRF52 are from nRF5_SDK_12.3.0_d7731ad.zip  Some files have been slightly modified