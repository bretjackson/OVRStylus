/*
  Copyright (c) 2014-2015 Arduino LLC.  All right reserved.
  Copyright (c) 2016 Sandeep Mistry All right reserved.
  Copyright (c) 2019 Forward Computing and Control Pty. Ltd. All right reserved.
  
  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "variant.h"

/*   GT832E_01

     A4  D4   P0.29                                    DIO
     A5  D5   P0.30                                    CLK
     A2  D6   P0.31                                    P0.14  D2 SDA0
              GND                                      P0.12  D1 TX
              VCC                                      P0.11  D0 RX

                P0.06  P0.07     P0.08    P0.09   P0.10  
                 D7     D8         D9      D10     D3
             SPI0_SS SPI0_MOSI SPI0_MISO SPI0_CLK SCL0

*/

// _VARIANT_GT832E_01_
// this pin mapping is for the Temp/RH board used as a Redbear NanoV2 replacement
// but it is missing A0,A1,A2,A3 and MRST
// _VARIANT_GT832E_01_ has pins D0/RX, D1/TX, D2/CTS/SDAO, D3/RTS/SCL0
// D6, D7, D8, D9, D10
// D4/A4, D5/A5
// there is NO led (D13) on this board
// Master Reset pin (MRST) is not accessable in this board
const uint32_t g_ADigitalPinMap[] = {
  // D0 - D4
  11, // D0
  12, // D1
  14, // D2
  10, // D3
  
  // D4/A4 - D6/A6
  29,  // D4/A4  
  30,  // D5/A5
  31,  // D6/A6

  // D7 - D10
  6,
  7,
  8,
  9,

  // D11 - D13 NOT AVAILABLE
  (uint32_t)-1,
  (uint32_t)-1,
  (uint32_t)-1  // no D13, no BUILT-IN LED
};
